﻿using System;
using System.ServiceModel;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Xrm.DevOPs.Agent.Contract;

namespace Xrm.DevOPs.Agent.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var binding = new System.ServiceModel.WSHttpBinding();
            var endpoint = new EndpointAddress("http://localhost:8000/DevOPsAgent/service");

            var factory = new ChannelFactory<IDeploy>(binding, endpoint);

            var channel = factory.CreateChannel();
            try
            {
                //var ret = channel.Release("aaaaaaa");
                var build = new Xrm.DevOPs.Agent.Contract.BuildContract()
                {
                    BuildNumber = "123",
                    Source = "MasterConfig",
                    Target = "ITIntegration"
                };
                var b = channel.PrepareBuild(build);
            }
            catch (Exception ex)
            {
                var message = ex.Message;
                var innerMessage = ex.InnerException?.Message;
            }

            //DeployClient client = new DeployClient()

            //client.Release("KYC-201806-1");

            // Utilisez la variable 'client' pour appeler des opérations sur le service.

            // Fermez toujours le client.
            //client.Close();

           
        }
    }
}
