﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Xrm.DevOPs.Agent.Contract;

namespace Xrm.DevOPs.Agent
{
    [ServiceContract(Namespace = "http://agent.devops.usbank.com")]
    public interface IDeploy
    {
        [OperationContract]
        string Release(string releaseName);

        [OperationContract]
        BuildContract PrepareBuild(BuildContract build);
    }
}
