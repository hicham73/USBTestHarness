﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xrm.DevOPs.Agent.Contract;

namespace Xrm.DevOPs.Agent
{
    public class DeployService : IDeploy
    {
        public string Release(string releaseName)
        {

            Directory.CreateDirectory("c:/temp/Deploy");
            Process.Start("calc.exe");

            throw new Exception("this is a custom exception");

            return "process started";
        }

        public BuildContract PrepareBuild(BuildContract build)
        {
            var build2 = new BuildContract()
            {
                BuildNumber = "246"
            };

            return build2;
        }
    }
}
